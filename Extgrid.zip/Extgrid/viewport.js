Ext.onReady(function(){
	Ext.create('Ext.container.Viewport', {
    layout: 'border',
    items: [{
        region: 'west',
        collapsible: true,
        title: 'Navigation',
        width: 150     
    }, {
        region: 'south',
        title: 'South Panel',
        collapsible: true,
        html: 'Information goes here',
        split: true,
        height: 100,
        minHeight: 100
    }, {
        region: 'east',
        title: 'East Panel',
        collapsible: true,
        split: true,
        width: 150
    }, {
			region: 'center',
			xtype: 'tabpanel', // TabPanel itself has no title
			activeTab: 0,      // First tab active by default
			items:grid
		}]
	});
	
	
	
});

var dataModel = Ext.define('info', {
	extend: 'Ext.data.Model',
    fields:[
		{name: 'name', type: 'string'},
		{name: 'email', type: 'string'},
		{name: 'phone', type: 'string'}
    ]
});

var datastore = Ext.create('Ext.data.Store', {	
	storeId:'simpsonsStore',
	model:dataModel,    
    data:[
        { 'name': 'Lisa',  "email":"lisa@simpsons.com",  "phone":"555-111-1224"  },
        { 'name': 'Bart',  "email":"bart@simpsons.com",  "phone":"555-222-1234" },
        { 'name': 'Homer', "email":"home@simpsons.com",  "phone":"555-222-1244"  },
        { 'name': 'Marge', "email":"marge@simpsons.com", "phone":"555-222-1254"  }
    ]
});
var grid = Ext.create('Ext.grid.Panel', {
	id:"grid",
	title: 'Simpsons',
	store: datastore,
	selType: 'rowmodel',
	plugins: [
        Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToEdit: 1
        })
    ],
	columns: [
		{ header: 'Name',  dataIndex: 'name', editor: {
                xtype: 'textfield',
                allowBlank: false
            } },
		{ header: 'Email', dataIndex: 'email', flex: 1, editor: {
                xtype: 'textfield',
                allowBlank: false
            }},
		{ header: 'Phone', dataIndex: 'phone' }
	],
	height: 200,		
	
});